// Copyright (C) 2004-2006 MySQL AB
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License version 2 as published by
// the Free Software Foundation
//
// There are special exceptions to the terms and conditions of the GPL 
// as it is applied to this software. View the full text of the 
// exception in file EXCEPTIONS in the directory of this software 
// distribution.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc.,59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 

using System;
using System.Collections;
using System.ComponentModel;
using System.Text;

namespace MySql.Data.MySqlClient
{
    public class DbConnectionStringBuilder : IDictionary, ICollection, IEnumerable, ICustomTypeDescriptor
	{
        private string connectionString;
        private Hashtable hash;
        private bool browsable;

        public DbConnectionStringBuilder()
        {
            hash = new Hashtable(StringComparer.InvariantCultureIgnoreCase);
            browsable = false;
        }

        #region Properties

        public bool BrowsableConnectionString 
        {
            get { return browsable; }
            set { browsable = value; }
        }
        
        public string ConnectionString 
        {
            get { return connectionString; }
            set 
            {
                Clear();
                ParseConnectionString(value);
                connectionString = value; 
            }
        }

        public virtual object this[string key]
        {
            get { return hash[key]; }
            set { Add(key, value);  }
        }

        #endregion

        #region IDictionary Members

        public void Add(object key, object value)
        {
            hash[key] = value;
            //TODO: update connection string
        }

        public virtual void Clear()
        {
            connectionString = null;
            hash.Clear();
        }

        public bool Contains(object key)
        {
            return hash.ContainsKey(key);
        }

        public IDictionaryEnumerator GetEnumerator()
        {
            return hash.GetEnumerator();
        }

        public bool IsFixedSize
        {
            get { return false; }
        }

        public bool IsReadOnly
        {
            get { return false; }
        }

        public ICollection Keys
        {
            get { return hash.Keys; }
        }

        public void Remove(object key)
        {
            hash.Remove(key);
            //TODO: update connection string
        }

        public ICollection Values
        {
            get { return hash.Values; }
        }

        public object this[object key]
        {
            get
            {
                return this[(string)key];
            }
            set
            {
                this[(string)key] = value;
            }
        }

        #endregion

        #region ICollection Members

        public void CopyTo(Array array, int index)
        {
            hash.CopyTo(array, index);
        }

        public int Count
        {
            get { return hash.Count; }
        }

        public bool IsSynchronized
        {
            get { return hash.IsSynchronized; }
        }

        public object SyncRoot
        {
            get { return hash.SyncRoot; }
        }

        #endregion

        #region IEnumerable Members

        IEnumerator IEnumerable.GetEnumerator()
        {
            return hash.GetEnumerator();
        }

        #endregion

        #region ICustomTypeDescriptor Members

        public AttributeCollection GetAttributes()
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public string GetClassName()
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public string GetComponentName()
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public TypeConverter GetConverter()
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public EventDescriptor GetDefaultEvent()
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public PropertyDescriptor GetDefaultProperty()
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public object GetEditor(Type editorBaseType)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public EventDescriptorCollection GetEvents(Attribute[] attributes)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public EventDescriptorCollection GetEvents()
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public PropertyDescriptorCollection GetProperties(Attribute[] attributes)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public PropertyDescriptorCollection GetProperties()
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public object GetPropertyOwner(PropertyDescriptor pd)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        #endregion

        public virtual object TryGetValue(string keyword, out object value)
        {
            if (!hash.ContainsKey(keyword))
            {
                value = null;
                return false;
            }
            value = hash[keyword];
            return true;
        }

        private void ParseConnectionString(string connectString)
        {
            if (connectString == null) return;

            StringBuilder key = new StringBuilder();
            StringBuilder value = new StringBuilder();
            bool keyDone = false;

            foreach (char c in connectString)
            {
                if (c == '=')
                    keyDone = true;
                else if (c == ';')
                {
                    string keyStr = key.ToString().Trim();
                    string valueStr = value.ToString().Trim();
                    valueStr = CleanValue(valueStr);
                    if (keyStr.Length > 0)
                        this[keyStr] = valueStr;
                    keyDone = false;
                    key.Remove(0, key.Length);
                    value.Remove(0, value.Length);
                }
                else if (keyDone)
                    value.Append(c);
                else
                    key.Append(c);
            }

            if (key.Length == 0) return;
            this[key.ToString().Trim()] = CleanValue(value.ToString().Trim());
        }

        private string CleanValue(string value)
        {
            if ((value.StartsWith("'") && value.EndsWith("'")) ||
                (value.StartsWith("\"") && value.EndsWith("\"")))
            {
                value = value.Substring(1);
                value = value.Substring(0, value.Length - 1);
            }
            return value;
        }

/*        private void ParseConnectionString(string value)
        {
            String[] keyvalues = src.Split(';');
            String[] newkeyvalues = new String[keyvalues.Length];
            int x = 0;

            // first run through the array and check for any keys that
            // have ; in their value
            foreach (String keyvalue in keyvalues)
            {
                // check for trailing ; at the end of the connection string
                if (keyvalue.Length == 0) continue;

                // this value has an '=' sign so we are ok
                if (keyvalue.IndexOf('=') >= 0)
                {
                    newkeyvalues[x++] = keyvalue;
                }
                else
                {
                    newkeyvalues[x - 1] += ";";
                    newkeyvalues[x - 1] += keyvalue;
                }
            }

            Hashtable hash = new Hashtable();

            // now we run through our normalized key-values, splitting on equals
            for (int y = 0; y < x; y++)
            {
                String[] parts = newkeyvalues[y].Split('=');

                // first trim off any space and lowercase the key
                parts[0] = parts[0].Trim().ToLower();
                parts[1] = parts[1].Trim();

                // we also want to clear off any quotes
                if (parts[1].Length >= 2)
                {
                    if ((parts[1][0] == '"' && parts[1][parts[1].Length - 1] == '"') ||
                        (parts[1][0] == '\'' && parts[1][parts[1].Length - 1] == '\''))
                    {
                        parts[1] = parts[1].Substring(1, parts[1].Length - 2);
                    }
                }
                else
                {
                    parts[1] = parts[1];
                }
                parts[0] = parts[0].Trim('\'', '"');

                hash[parts[0]] = parts[1];
            }
            return hash;
        }*/
    }
}
